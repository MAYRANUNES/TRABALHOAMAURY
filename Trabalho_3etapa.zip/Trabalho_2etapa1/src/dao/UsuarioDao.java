package dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entidades.Usuario;

public class UsuarioDao {
	
	public UsuarioDao(){
		
	}
	public boolean salvar(Usuario user){
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		
		try{
			
			session.beginTransaction();
			session.save(user);			
			session.getTransaction().commit();
			return true;
		
		}catch ( HibernateException e ) {
			if ( session.getTransaction() != null )
				session.getTransaction().rollback();
			return false;
		} finally {
			session.close();
		}
		
	}
	public List<Usuario> listar(){
		List<Usuario> result =new ArrayList<>();
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		try{
			session.beginTransaction();		
			session.getTransaction().commit();
			result=session.createQuery("from Usuario").list();
		}catch ( HibernateException e ) {
			if ( session.getTransaction() != null )
				session.getTransaction().rollback();
		}
		return result;
	}
	
	public int login(Usuario user){
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Query query;
		try{
			query = session.createQuery("from Usuario where nome=:user and senha=:passwd");
			query.setParameter("user", user.getNome());
			query.setParameter("passwd", user.getSenha());
			@SuppressWarnings("unchecked")
			List<Usuario> usuarios = query.getResultList();
			if(usuarios.size()>0)
				return 1;
		}catch ( HibernateException e ) {
			if ( session.getTransaction() != null )
				session.getTransaction().rollback();
		} finally {
			session.close();
		}
		return 0;
	}

}